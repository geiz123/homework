$(document).ready(function(){
 

        
	$(".slideme").hide();
        
	$(".show_hide").show();
 
    

     $('.show_hide').click(function(){
    
     $(".slideme").slideToggle();
    
     });
 


});
 
