/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.sugar.entity.Address;
import java.util.List;
import javax.sql.DataSource;

public interface AddressDao {
    /**
     * Needed by SpringContainer to set our dataSource. 
     * @param ds
     */
    public void setDataSource(DataSource ds);
    /**
     * Get all ContactRecord
     * @return
     */
    public List<Address> getAll();
}
