package com.dao.impl;

import com.dao.AddressDao;
import com.sugar.entity.Address;
import com.sugar.entity.mapper.AddressMapper;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class AddressDaoImpl implements AddressDao {
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public void setDataSource(DataSource ds) {
        this.jdbcTemplate = new JdbcTemplate(ds);
    }

    @Override
    public List<Address> getAll() {
        String sql = "select * from address";
        
        List<Address> a = jdbcTemplate.query(sql, new AddressMapper());
        
        return a;
    }

}
