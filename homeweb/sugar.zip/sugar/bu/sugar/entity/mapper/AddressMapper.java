package com.sugar.entity.mapper;

import com.sugar.entity.Address;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class AddressMapper implements RowMapper<Address> {

    @Override
    public Address mapRow(ResultSet rs, int rowNum) throws SQLException {
        Address add = new Address();
        
        add.setAddressid(rs.getInt("addressid"));
        add.setStreet1(rs.getString("street1"));
        add.setStreet2(rs.getString("street2"));
        add.setCity(rs.getString("city"));
        add.setState(rs.getString("state"));
        add.setZipcode(rs.getString("zipcode"));
        
        return add;
    }

}
