package hd.spring.config;

import java.util.logging.Logger;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
// Scan for all of Spring components such as Spring Service
@ComponentScan(basePackages = {"hd.spring.*"})
// Detect @Transactional
public class SpringConfig {

    private static final Logger LOGGER = Logger.getLogger("SpringConfig.class");
    
//    @Bean
//    public DataSource dataSource() throws Exception {
//        
//        LOGGER.log(Level.SEVERE, "%^& In dataSource %^&");
//        
//        Context ctx = new InitialContext();
//        return (DataSource) ctx.lookup("java:jboss/datasources/h2home");
//    }
    
}
